// Copyright 2012 Google Inc.

#import "NSDictionary+GCKAdditions.h"
